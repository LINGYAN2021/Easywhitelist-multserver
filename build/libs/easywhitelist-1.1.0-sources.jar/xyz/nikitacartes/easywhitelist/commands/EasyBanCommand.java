package xyz.nikitacartes.easywhitelist.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import xyz.nikitacartes.easywhitelist.integrations.Permissions;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.class_2196.method_9339;
import static net.minecraft.class_2196.method_9340;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_3016.method_13022;
import static xyz.nikitacartes.easywhitelist.EasyWhitelist.getProfileFromNickname;

public class EasyBanCommand {

    public static void registerCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("easyban")
                .requires(Permissions.require("easywhitelist.commands.easyban", 3))
                .then((method_9244("targets", word())
                        .executes(ctx ->
                                method_13022(ctx.getSource(), getProfileFromNickname(getString(ctx, "targets")), null)))
                        .then(method_9244("reason", method_9340())
                                .executes(ctx ->
                                        method_13022(ctx.getSource(), getProfileFromNickname(getString(ctx, "targets")), method_9339(ctx, "reason"))))));
    }
}

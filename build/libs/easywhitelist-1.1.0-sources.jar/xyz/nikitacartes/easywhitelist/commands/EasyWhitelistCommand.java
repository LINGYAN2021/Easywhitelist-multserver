package xyz.nikitacartes.easywhitelist.commands;

import com.mojang.brigadier.CommandDispatcher;
import xyz.nikitacartes.easywhitelist.EasyWhitelist;
import xyz.nikitacartes.easywhitelist.integrations.Permissions;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import net.minecraft.class_3337;
import net.minecraft.class_4844;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_3156.method_13838;
import static net.minecraft.class_3156.method_13845;
import static xyz.nikitacartes.easywhitelist.EasyWhitelist.getProfileFromNickname;

public class EasyWhitelistCommand {

    public static void registerCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("easywhitelist")
                .requires(Permissions.require("easywhitelist.commands.easywhitelist.root", 3))
                .then(method_9247("add")
                        .requires(Permissions.require("easywhitelist.commands.easywhitelist.add", 3))
                        .then(method_9244("targets", word())
                                .executes(ctx -> {
                                    String name = getString(ctx, "targets");
                                    int result = method_13838(ctx.getSource(), getProfileFromNickname(name));
                                    if (EasyWhitelist.isDatabaseEnabled()) {
                                        String uuid = class_4844.method_43344(name).toString();
                                        EasyWhitelist.databaseManager.addToWhitelist(name, uuid);
                                        ctx.getSource().method_9226(() -> class_2561.method_43470("[DB] Synced '" + name + "' to database whitelist."), true);
                                    }
                                    return result;
                                })
                        )
                )
                .then(method_9247("remove")
                        .requires(Permissions.require("easywhitelist.commands.easywhitelist.remove", 3))
                        .then(method_9244("targets", word())
                                .executes(ctx -> {
                                    String name = getString(ctx, "targets");
                                    int result = method_13845(ctx.getSource(), getProfileFromNickname(name));
                                    if (EasyWhitelist.isDatabaseEnabled()) {
                                        EasyWhitelist.databaseManager.removeFromWhitelist(name);
                                        ctx.getSource().method_9226(() -> class_2561.method_43470("[DB] Removed '" + name + "' from database whitelist."), true);
                                    }
                                    return result;
                                })
                        )
                )
                .then(method_9247("sync")
                        .requires(Permissions.require("easywhitelist.commands.easywhitelist.root", 3))
                        .executes(ctx -> {
                            if (!EasyWhitelist.isDatabaseEnabled()) {
                                ctx.getSource().method_9213(class_2561.method_43470("[EasyWhitelist] Database is not enabled."));
                                return 0;
                            }
                            EasyWhitelist.databaseManager.refreshCache();
                            Set<String> list = EasyWhitelist.databaseManager.getAllWhitelisted();
                            ctx.getSource().method_9226(() -> class_2561.method_43470("[DB] Whitelist synced. " + list.size() + " players in database."), true);
                            return 1;
                        })
                )
                .then(method_9247("dblist")
                        .requires(Permissions.require("easywhitelist.commands.easywhitelist.root", 3))
                        .executes(ctx -> {
                            if (!EasyWhitelist.isDatabaseEnabled()) {
                                ctx.getSource().method_9213(class_2561.method_43470("[EasyWhitelist] Database is not enabled."));
                                return 0;
                            }
                            Set<String> list = EasyWhitelist.databaseManager.getAllWhitelisted();
                            if (list.isEmpty()) {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("[DB] Database whitelist is empty."), false);
                            } else {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("[DB] Whitelisted (" + list.size() + "): " + String.join(", ", list)), false);
                            }
                            return 1;
                        })
                )
                .then(method_9247("import")
                        .requires(Permissions.require("easywhitelist.commands.easywhitelist.root", 3))
                        .executes(ctx -> {
                            if (!EasyWhitelist.isDatabaseEnabled()) {
                                ctx.getSource().method_9213(class_2561.method_43470("[EasyWhitelist] Database is not enabled."));
                                return 0;
                            }
                            var whitelist = ctx.getSource().method_9211().method_3760().method_14590();
                            String[] names = whitelist.method_14636();
                            if (names.length == 0) {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("[EasyWhitelist] Vanilla whitelist is empty, nothing to import."), false);
                                return 0;
                            }
                            Map<String, String> nameUuidMap = new LinkedHashMap<>();
                            for (String name : names) {
                                String uuid = class_4844.method_43344(name).toString();
                                nameUuidMap.put(name, uuid);
                            }
                            int result = EasyWhitelist.databaseManager.bulkAddToWhitelist(nameUuidMap);
                            if (result >= 0) {
                                ctx.getSource().method_9226(() -> class_2561.method_43470("[DB] Successfully imported " + nameUuidMap.size() + " players from vanilla whitelist into database."), true);
                            } else {
                                ctx.getSource().method_9213(class_2561.method_43470("[EasyWhitelist] Failed to import whitelist. Check server logs."));
                            }
                            return 1;
                        })
                )
                .then(method_9247("reload")
                        .requires(Permissions.require("easywhitelist.commands.easywhitelist.root", 3))
                        .executes(ctx -> {
                            EasyWhitelist.databaseConfig = xyz.nikitacartes.easywhitelist.config.DatabaseConfig.load();
                            ctx.getSource().method_9226(() -> class_2561.method_43470("[EasyWhitelist] Config reloaded."), true);
                            return 1;
                        })
                )
                .then(method_9247("status")
                        .requires(Permissions.require("easywhitelist.commands.easywhitelist.root", 3))
                        .executes(ctx -> {
                            boolean dbEnabled = EasyWhitelist.databaseConfig != null && EasyWhitelist.databaseConfig.enabled;
                            boolean dbConnected = EasyWhitelist.isDatabaseEnabled();
                            boolean vanillaWhitelist = ctx.getSource().method_9211().method_3760().method_14614();
                            int cacheSize = dbConnected ? EasyWhitelist.databaseManager.getAllWhitelisted().size() : 0;
                            String serverId = EasyWhitelist.databaseConfig != null ? EasyWhitelist.databaseConfig.serverId : "N/A";

                            ctx.getSource().method_9226(() -> class_2561.method_43470(
                                    "§6[EasyWhitelist Status]\n" +
                                    "§f  Vanilla whitelist: " + (vanillaWhitelist ? "§aENABLED" : "§cDISABLED") + "\n" +
                                    "§f  DB config enabled: " + (dbEnabled ? "§aYES" : "§cNO") + "\n" +
                                    "§f  DB connected: " + (dbConnected ? "§aYES" : "§cNO") + "\n" +
                                    "§f  Server ID: §b" + serverId + "\n" +
                                    "§f  Cache entries: §b" + cacheSize
                            ), false);
                            return 1;
                        })
                )
        );
    }

}

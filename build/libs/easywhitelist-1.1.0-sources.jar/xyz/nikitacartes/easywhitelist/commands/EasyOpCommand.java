package xyz.nikitacartes.easywhitelist.commands;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import xyz.nikitacartes.easywhitelist.integrations.Permissions;

import static com.mojang.brigadier.arguments.StringArgumentType.getString;
import static com.mojang.brigadier.arguments.StringArgumentType.word;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;
import static net.minecraft.class_3083.method_13465;
import static xyz.nikitacartes.easywhitelist.EasyWhitelist.getProfileFromNickname;

public class EasyOpCommand {

    public static void registerCommand(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("easyop")
                .requires(Permissions.require("easywhitelist.commands.easyop", 4))
                .then(method_9244("targets", word())
                        .executes(ctx ->
                                method_13465(ctx.getSource(), getProfileFromNickname(getString(ctx, "targets"))))));
    }
}
